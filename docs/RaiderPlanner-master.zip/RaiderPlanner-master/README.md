# PearPlanner  
#### The best study planner since the Gantt Diagram




| Branch  | Build status  |
| ------------- | ------------- |
| origin/master: | [![Build Status](https://travis-ci.org/Alienturnedhuman/PearPlanner.svg?branch=master)](https://travis-ci.org/Alienturnedhuman/PearPlanner)  |
| origin/Alienturnedhuman:  | [![Build Status2](https://travis-ci.org/Alienturnedhuman/PearPlanner.svg?branch=Alienturnedhuman)](https://travis-ci.org/Alienturnedhuman/PearPlanner)  |
| origin/aBranch: | [![Build Status3](https://travis-ci.org/Alienturnedhuman/PearPlanner.svg?branch=aBranch)](https://travis-ci.org/Alienturnedhuman/PearPlanner)  |
| origin/zBranch: | [![Build Status4](https://travis-ci.org/Alienturnedhuman/PearPlanner.svg?branch=zBranch)](https://travis-ci.org/Alienturnedhuman/PearPlanner)  |
| origin/Bijan: | [![Build Status4](https://travis-ci.org/Alienturnedhuman/PearPlanner.svg?branch=Bijan)](https://travis-ci.org/Alienturnedhuman/PearPlanner)  |


